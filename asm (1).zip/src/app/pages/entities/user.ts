export interface User {
    userId: number;
    userName: string;
    email: string;
    address: string;   
    }