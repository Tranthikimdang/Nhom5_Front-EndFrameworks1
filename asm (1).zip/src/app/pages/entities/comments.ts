export interface Icomments {
    commentsId: number;
    userName: string;
    commentsEmail: string;
    productName: string;
    imageUrl: string;
    commentsContent: string;
    commentsDate: string;
   }