export interface Order {
    orderID: number;
    client: string;
    quantity: number;
    date: string;
    valueOrder: string;
    payment: string;
}
