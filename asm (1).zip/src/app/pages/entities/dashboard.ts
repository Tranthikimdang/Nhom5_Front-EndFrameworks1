export interface Dashboard {
    dashboardID: number;
    name: string;
    cateName: string;
    price: number;
    qty: number;
    imageURL: string;
  }
