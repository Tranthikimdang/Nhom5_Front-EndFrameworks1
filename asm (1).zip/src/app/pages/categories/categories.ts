export interface Category {
    cateId: number;
    cateName: string;     
}