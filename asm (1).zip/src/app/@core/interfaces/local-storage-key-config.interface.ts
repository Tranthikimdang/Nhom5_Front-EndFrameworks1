export interface ILocalStorageKeyConfig {
  userInfo: string;
  token: string;
}
