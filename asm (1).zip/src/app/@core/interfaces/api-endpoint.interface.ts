export interface IAPIEndpoint {
  auth: any;
}
