export class IMessageError {
  required?: string;
  minLength?: string;
  maxLength?: string;
  invalid?: string;
  confirm?: string;
}
